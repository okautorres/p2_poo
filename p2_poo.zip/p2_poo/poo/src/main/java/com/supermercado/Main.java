package com.supermercado;

import com.supermercado.util.ConexaoBD;
import com.supermercado.view.ProdutoPanel;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        try {
            // Teste de conexão com o banco
            if (ConexaoBD.getConexao() == null) {
                JOptionPane.showMessageDialog(null, "Erro ao conectar ao banco de dados.");
                return;
            }

            // Criar janela principal
            SwingUtilities.invokeLater(() -> {
                JFrame frame = new JFrame("Sistema de Supermercado");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setSize(800, 600);
                frame.setLocationRelativeTo(null);

                // Adiciona painel inicial (pode trocar por outro como AjusteEstoquePanel)
                ProdutoPanel panel = new ProdutoPanel();
                frame.setContentPane(panel);

                frame.setVisible(true);
            });

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro na conexão com o banco: " + e.getMessage());
        }
    }
}
